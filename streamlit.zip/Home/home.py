# Home/home.py
import streamlit as st
st.write("This is the home page")



